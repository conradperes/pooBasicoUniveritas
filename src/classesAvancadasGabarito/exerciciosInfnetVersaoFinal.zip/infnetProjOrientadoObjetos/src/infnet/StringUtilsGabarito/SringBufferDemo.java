package infnet.StringUtilsGabarito;

public class SringBufferDemo {

	public static void main(String[] args) {
		StringBuffer buffer = new StringBuffer();
		buffer.append("Curso ").append("de ").append("Programa��o ").append(
				"Orientada a Objetos ").append(" em java");
		System.out.println(buffer.toString());
	}
}
