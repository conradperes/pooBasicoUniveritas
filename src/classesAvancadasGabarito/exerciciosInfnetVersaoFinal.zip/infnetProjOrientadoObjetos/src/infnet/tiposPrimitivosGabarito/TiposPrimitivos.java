package infnet.tiposPrimitivosGabarito;

public class TiposPrimitivos {
	public static void main(String[] args) {
		//declara��o de vari�veis inteiras
		int x,y;
		//declara��o e atribui��o de pontos flutuantes do tipo float
		float z=3.414f;
		//declara��o e atribui��o do tipo double
		double w=3.1415;
		//declara��o e atribui��o do tipo boolean
		boolean truth=true;
		//declara��o do tipo char
		char c;
		//declara��o e atribui��o do tipo String
		String str="Ol�!!!";
		//atribui��o do tipo char
		c='A';
		//Sobrescrevendo valor inicial
		str ="outro valor!";
		//atribuindo valores diferentes as vari�veis int criadas acima
		x=6;
		y=1000;		
	}
}
