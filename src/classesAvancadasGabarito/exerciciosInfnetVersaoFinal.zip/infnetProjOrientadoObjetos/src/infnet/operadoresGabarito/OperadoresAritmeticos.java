package infnet.operadoresGabarito;

public class OperadoresAritmeticos {

	public static void main(String[] args) {

		double a = 77.7d;
		double b = 99.9d;
		System.out.println("Resultado da multiplica��o=" + a * b);

		int x = 90;
		int y = 176;
		System.out.println("Resultado da soma=" + x + y);

		int xy = 90;
		int yx = 176;
		int resultado = xy - yx;
		System.out.println("Resultado da subtra��o=" + resultado);

		double ab = 77.7d;
		double ba = 99.9d;
		System.out.println("Resultado da multiplica��o=" + ab / ba);

		System.out.println("M�dulo=" + y % x);

	}

}
