package infnet.operadoresGabarito;

public class RegrasPrecedencia {
	public static void main(String[] args) {

		int a = 30;
		int b = 5;
		int c = 10;
		int total = (a + b + c) / 10;
		System.out.println("O resultado = " + total);
	}
}
