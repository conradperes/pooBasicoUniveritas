package infnet.operadoresGabarito;

public class EstruturaCondicionalIgualdade {
	public static void main(String[] args) {
		int idade = 17;
		if (idade <= 17) {
			System.out.println("Essa pessoa � menor de idade");
		}
		boolean virarDireta=true;
		if(virarDireta){
			System.out.println("Esse � o caminho certo para sua casa em B�zios");
		}
	}
}
