package infnet.operadoresGabarito;

public class OperadorRelacional {

	public static void main(String[] args) {
		int primeiroValor = 7;
		int segundoValor = 17;
		if (primeiroValor < segundoValor)
			System.out.printf("%d � menor que %d", primeiroValor, segundoValor);
	}
}
