package infnet.loopsGabarito;

public class GabaritoForEach {
	public static void main(String[] args) {
		String []nameArray={"Joana", "Victorio", "Ana", "Josefino", "Magda"};
		for (String name : nameArray) {
			System.out.println("Nome="+name);
		}
	}
}
