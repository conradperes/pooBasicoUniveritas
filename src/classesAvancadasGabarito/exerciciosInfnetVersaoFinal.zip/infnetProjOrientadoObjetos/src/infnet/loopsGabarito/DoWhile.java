package infnet.loopsGabarito;

public class DoWhile {
	public static void main(String[] args) {
		int i = 0;
		do {
			System.out.printf("Terminou?? %d", i);
			System.out.println();
			i++;
		} while (i < 10);
		System.out.println("agora terminou!");
	}
}
