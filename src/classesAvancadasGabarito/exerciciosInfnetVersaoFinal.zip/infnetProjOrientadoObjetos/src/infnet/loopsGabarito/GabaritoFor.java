package infnet.loopsGabarito;

public class GabaritoFor {
	public static void main(String[] args) {

		for(float f=0.0f;f<=1000f;f++){
			System.out.printf("valor do float %f \n", f);
		}
		for(float f=1000.0f;f>=0f;f--){
			System.out.printf("valor do float %f \n", f);
		}
	}

}
