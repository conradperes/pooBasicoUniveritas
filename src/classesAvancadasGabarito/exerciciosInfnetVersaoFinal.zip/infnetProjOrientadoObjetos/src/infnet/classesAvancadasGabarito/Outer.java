package infnet.classesAvancadasGabarito;

public class Outer {  
	public static void main(String[] args) {
		//Inner i = new Inner();
	}

	class Inner {
	}
}
