package infnet.classesAvancadasGabarito;

import javax.swing.JOptionPane;

public class AssertionSimples {
	private static final String MSG_FAVOR_DIGITE_NUM = "favor digitar um numero";
	static int x = 0;

	public static void main(String[] args) {
		String numero = assertDigitacao();
		x = new Integer(numero);
		assertX();
	}

	private static String assertDigitacao() {
		String numero = JOptionPane.showInputDialog(null,
				"Digite um valor para x");
		assert(numero == null):MSG_FAVOR_DIGITE_NUM;
		return numero;
	}

	private static void assertX() throws AssertionError {
		assert (x > 0) : "X é " + x;
		System.out
				.println("Se a afirmacao acima for negativa o programa continua seu fluxo normal"
						+ "porém se x for negativo ou 0 uma Excecao AssertionError é disparada");
	}
}
