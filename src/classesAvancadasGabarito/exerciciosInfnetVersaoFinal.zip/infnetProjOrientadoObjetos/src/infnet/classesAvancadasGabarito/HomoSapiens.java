package infnet.classesAvancadasGabarito;

import infnet.herancaGabarito.Animal;

public class HomoSapiens extends Animal {

}
