package infnet.classesAvancadasGabarito;

public class Aviao implements Voador {

	@Override
	public void decolar() {
		System.out.println("avião decolou");
	}

	@Override
	public void aterrisar() {
		System.out.println("avião aterrisou");

	}

	@Override
	public void voar() {
		 System.out.println("avião voou");

	}

}
