package infnet.classesAvancadasGabarito;

import infnet.herancaGabarito.Animal;

public class Passaro extends Animal implements Voador {

	@Override
	public void decolar() {
		// TODO Auto-generated method stub

	}

	@Override
	public void aterrisar() {
		// TODO Auto-generated method stub

	}

	@Override
	public void voar() {
		// TODO Auto-generated method stub

	}

	public void construirNinho() {
		/**
		 * implemetacao do metodo
		 */
	}

	public void porOvos() {
		/**
		 * implemetacao do metodo
		 */
	}

	public void comer() {
		/**
		 * implemetacao do metodo
		 */
	}
}
