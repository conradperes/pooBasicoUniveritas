package infnet.classesAvancadasGabarito;

public enum SOEnum {
	
	ANDROID, IBMOS, HPUX, IOS, UNIX ,LINUX, WINDOWS, XOS;

}
