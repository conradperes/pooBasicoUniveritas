package infnet.classesAvancadasGabarito;

public class LogParameter {
	public Object obj;

	public LogParameter(Object obj) {
		this.obj = obj;
	}
}