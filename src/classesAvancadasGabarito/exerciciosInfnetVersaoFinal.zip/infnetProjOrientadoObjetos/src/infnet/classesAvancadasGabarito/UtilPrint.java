package infnet.classesAvancadasGabarito;

public class UtilPrint {

	public UtilPrint() {
		super();
	}

	public void log(Object obj) {
		System.out.println(obj);
	}

}