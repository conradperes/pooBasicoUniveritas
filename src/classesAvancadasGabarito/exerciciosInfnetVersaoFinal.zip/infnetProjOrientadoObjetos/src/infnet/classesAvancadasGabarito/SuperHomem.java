package infnet.classesAvancadasGabarito;

public class SuperHomem extends HomoSapiens implements Voador {

	@Override
	public void decolar() {
		System.out.println("Decolando a 1000 Km/hora");

	}

	@Override
	public void aterrisar() {
		// TODO Auto-generated method stub

	}

	@Override
	public void voar() {
		// TODO Auto-generated method stub

	}

}
