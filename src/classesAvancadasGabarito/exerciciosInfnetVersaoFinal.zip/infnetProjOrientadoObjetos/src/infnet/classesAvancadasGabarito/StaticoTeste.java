package infnet.classesAvancadasGabarito;

public class StaticoTeste {
	
	private static final double DEFAULT_INTEREST_RATE=3.2;
	public StaticoTeste() {
		System.out.println(DEFAULT_INTEREST_RATE);
	}
	public static void main(String[] args) {
		//DEFAULT_INTEREST_RATE=23;
	}

}
