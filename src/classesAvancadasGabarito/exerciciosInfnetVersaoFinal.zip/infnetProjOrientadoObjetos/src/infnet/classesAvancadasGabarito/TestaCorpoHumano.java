package infnet.classesAvancadasGabarito;

public class TestaCorpoHumano {

	public static void main(String[] args) {
		CorpoHumano corpoHumano = new CorpoHumano();
		CorpoHumano.Orgaos orgaos= corpoHumano.new Orgaos();
		orgaos.pulmaoRespirando();
	}

}
