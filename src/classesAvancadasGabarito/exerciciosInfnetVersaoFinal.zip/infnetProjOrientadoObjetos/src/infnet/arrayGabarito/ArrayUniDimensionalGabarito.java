package infnet.arrayGabarito;

public class ArrayUniDimensionalGabarito {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		int array[] = new int[35];
		for(int i=0;i<35;i++){
			array[i]=i;
			System.out.println(array[i]);
		}
	}

}
