package infnet.nio2Gabarito;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class ReadWriteTextFileJDK7 {
	//Gabarito do código de leitura e gravação de arquivos versão 7
	final static String FILE_NAME = "/Users/conradmarquesperes/conrad/input.txt";
	final static String OUTPUT_FILE_NAME = "/Users/conradmarquesperes/conrad/output.txt";
	final static Charset ENCODING = StandardCharsets.UTF_8;

	public static void main(String... aArgs) throws IOException {
		ReadWriteTextFileJDK7 text = new ReadWriteTextFileJDK7();

		// treat as a small file
		try {
			List<String> lines = text.readSmallTextFile(FILE_NAME);
			log(lines);
			lines.add("Essa é uma linha adicionada ao código.");
			text.writeSmallTextFile(lines, FILE_NAME);

			// treat as a large file - use some buffering
			text.readLargerTextFile(FILE_NAME);
			lines = Arrays.asList("Abaixo da linha da água", "água de amor");
			text.writeLargerTextFile(OUTPUT_FILE_NAME, lines);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// For smaller files

	List<String> readSmallTextFile(String aFileName) throws IOException {
		Path path = Paths.get(aFileName);
		return Files.readAllLines(path, ENCODING);
	}

	void writeSmallTextFile(List<String> aLines, String aFileName)
			throws IOException {
		Path path = Paths.get(aFileName);
		Files.write(path, aLines, ENCODING);
	}

	// For larger files

	void readLargerTextFile(String aFileName) throws IOException {
		Path path = Paths.get(aFileName);
		try (Scanner scanner = new Scanner(path, ENCODING.name())) {
			while (scanner.hasNextLine()) {
				// process each line in some way
				log(scanner.nextLine());
			}
		}
	}

	void readLargerTextFileAlternate(String aFileName) throws IOException {
		Path path = Paths.get(aFileName);
		try (BufferedReader reader = Files.newBufferedReader(path, ENCODING)) {
			String line = null;
			while ((line = reader.readLine()) != null) {
				// process each line in some way
				log(line);
			}
		}
	}

	void writeLargerTextFile(String aFileName, List<String> aLines)
			throws IOException {
		Path path = Paths.get(aFileName);
		try (BufferedWriter writer = Files.newBufferedWriter(path, ENCODING)) {
			for (String line : aLines) {
				writer.write(line);
				writer.newLine();
			}
		}
	}

	private static void log(Object aMsg) {
		System.out.println("Inicio do log=" + String.valueOf(aMsg));
	}

}
