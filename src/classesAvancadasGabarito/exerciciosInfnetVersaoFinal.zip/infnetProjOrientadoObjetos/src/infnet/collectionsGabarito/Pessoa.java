package infnet.collectionsGabarito;

public class Pessoa {
	String nome;
	Integer idade;
	String endereco;

	public String getNome() {
		return nome;
	}

	public Integer getIdade() {
		return idade;
	}

	public String getEndereco() {
		return endereco;
	}

	public Pessoa(String nome, Integer idade, String endereco) {
		this.nome = nome;
		this.idade=idade;
		this.endereco=endereco;
	}

}
