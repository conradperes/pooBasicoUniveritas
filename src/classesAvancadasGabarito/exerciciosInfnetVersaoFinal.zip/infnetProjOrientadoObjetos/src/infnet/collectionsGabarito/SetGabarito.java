package infnet.collectionsGabarito;

import java.util.HashSet;
import java.util.Set;

public class SetGabarito {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Set set = new HashSet();
		set.add(5.0);
		set.add(4.77);
		set.add(4.77);
		set.add(2.7589);
		set.add(1.3);
		set.add(4.77);
		set.add(4.0);
		set.add(1.4);
		System.out.println(set);

	}

}
