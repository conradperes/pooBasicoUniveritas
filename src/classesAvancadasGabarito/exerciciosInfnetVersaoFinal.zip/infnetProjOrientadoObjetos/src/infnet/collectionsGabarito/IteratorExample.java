package infnet.collectionsGabarito;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.SortedSet;
import java.util.TreeSet;

public class IteratorExample {
	public static void main(String[] args) {
		SortedSet frutas = new TreeSet();
		for (String fruta : Arrays.asList("mango", "apple", "banana", "banana")) {
			frutas.add(fruta);
		}
		Iterator iterator = frutas.iterator();
		while (iterator.hasNext()) {
			String fruta = (String) iterator.next();
			System.out.println(fruta);
		}
		List l = new ArrayList();
		l.addAll(frutas);
		ListIterator listIterator = l.listIterator();
		while (listIterator.hasNext()) {
			String fruta = (String) listIterator.next();
			System.out.println(fruta);
		}
	}
}
