package infnet.collectionsGabarito;

import java.util.ArrayList;
import java.util.List;

public class ListExample {
	public static void main(String[] args) {
		List list = new ArrayList();
		list.add(5);
		list.add(4);
		list.add(4);
		list.add(2);
		list.add(1);
		list.add(4);
		list.add(4);
		list.add(4);
		System.out.println(list);
		//http://docs.oracle.com/javase/6/docs/api/java/util/ArrayList.html
	}
}
