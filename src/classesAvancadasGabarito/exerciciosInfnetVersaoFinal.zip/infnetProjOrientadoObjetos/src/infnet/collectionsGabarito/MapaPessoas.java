package infnet.collectionsGabarito;

import java.util.HashMap;
import java.util.Map;

public class MapaPessoas {

	public static void main(String[] args) {
		Map mapa = new HashMap();
		mapa.put(99, new Pessoa("Conrad", 99, "Rua S�o Jose 90..."));
		mapa.put(1, new Pessoa("Edeverdison", 99, "Rua S�o Edevardison 90..."));
		mapa.put(7, new Pessoa("Jose", 99, "Rua S�o Jose da silva 90..."));
		mapa.put(77, new Pessoa("Maria", 99, "Rua S�o Maria 90..."));
		Pessoa pessoa = (Pessoa) mapa.get(77);
		System.out.print(pessoa.getNome() + "\n");
		System.out.print(pessoa.getEndereco());
	}

}
