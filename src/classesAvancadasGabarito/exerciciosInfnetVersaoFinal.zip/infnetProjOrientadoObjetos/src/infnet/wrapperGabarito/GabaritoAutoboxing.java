package infnet.wrapperGabarito;

public class GabaritoAutoboxing {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		Integer i = 7;
		Float f = 6.7f;
		Double d = 7.5;
		Boolean b = true;
		Byte byteS = 5;
		Character c = 'g';
		Long l = 7777l;
		Short s = 3;
		System.out.println(i);
		System.out.println(f);
		System.out.println(d);
		System.out.println(b);
		System.out.println(byteS);
		System.out.println(c);
		System.out.println(l);
		System.out.println(s);
	}

}
