package infnet.wrapperGabarito;

public class Autoboxing {

	public static void main(String[] args) {
		Integer x =9;
		int y = x;
		System.out.println(x);
		System.out.println(y);
	}

}
