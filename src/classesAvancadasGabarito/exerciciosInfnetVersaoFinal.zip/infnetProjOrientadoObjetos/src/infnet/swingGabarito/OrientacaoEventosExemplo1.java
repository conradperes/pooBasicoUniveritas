package infnet.swingGabarito;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class OrientacaoEventosExemplo1 extends JFrame implements ActionListener {
	private static final long serialVersionUID = 5689209775317132424L;
	JButton botao;
	JPanel panel;
	JTextField texto;
	JDialog dialog;
	
	public OrientacaoEventosExemplo1() {
		super("GUJ - Java");
	}

	public void criaJanela() {
		texto = new JTextField("Digite algo...");

		panel = new JPanel();
		panel.setLayout(new GridLayout(2, 1));

		botao = new JButton("Clique Aqui");
		botao.addActionListener(this);

		panel.add(texto);
		panel.add(botao);

		getContentPane().add(panel, BorderLayout.CENTER);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		pack();
		setVisible(true);
	}

	public void actionPerformed(ActionEvent event) {
		botao.setText(texto.getText());
		JOptionPane.showMessageDialog(this, "Clicou no botão e digitou="+texto.getText());
		
	}

	public static void main(String args[]) {
		OrientacaoEventosExemplo1 ex2 = new OrientacaoEventosExemplo1();
		ex2.criaJanela();
	}
}