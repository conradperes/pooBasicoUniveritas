package infnet.swingGabarito;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
public class BoxLayoutTest extends JFrame  
{  
    /**
	 * 
	 */
	private static final long serialVersionUID = 7010576866134973904L;

	public BoxLayoutTest()  
    {  
        JPanel panel = new JPanel();  
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));  
          
        JButton botao1 = new JButton("Botão 1");  
        JButton botao2 = new JButton("Botão 2");  
        JButton botao3 = new JButton("Botão 3");  
        JButton botao4 = new JButton("Botão 4");  
        JButton botao5 = new JButton("Botão 5");  
          
        panel.add(botao1);  
        panel.add(botao2);  
        panel.add(botao3);  
        panel.add(botao4);  
        panel.add(botao5);  
          
        getContentPane().add(panel);  
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
          
        pack();  
        setVisible(true);  
    }  
      
    public static void main(String args[])  
    {  
        new BoxLayoutTest();  
    }  
}  
