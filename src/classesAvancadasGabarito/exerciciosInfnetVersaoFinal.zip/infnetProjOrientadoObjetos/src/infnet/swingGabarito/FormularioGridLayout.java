package infnet.swingGabarito;

import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class FormularioGridLayout extends JFrame {

	private static final long serialVersionUID = 1L;
	private JLabel labelNome;
	private JTextField textFieldNome;
	private JLabel labelRG;
	private JTextField textFieldRG;
	private JLabel labelCPF;
	private JTextField textFieldCPF;
	private JLabel labelTelefone;
	private JTextField textFieldTelefone;
	private JButton buttonOk;
	private JLabel labelSexo;
	private JCheckBox checkSexo;
	private JLabel labelOBS;
	private JTextArea formattedTextFieldOBS;
	

	public FormularioGridLayout() {
		// --> muda o titulo e o leiaute
		setTitle("Formulário Cliente");
		setLayout(new GridLayout(7, 2));
		// --> instancia os componentes
		labelNome = new JLabel("Nome: ");
		textFieldNome = new JTextField(15);
		labelRG = new JLabel("RG: ");
		textFieldRG = new JTextField(15);
		labelCPF = new JLabel("CPF: ");
		textFieldCPF = new JTextField(15);
		labelTelefone = new JLabel("Telefone: ");
		textFieldTelefone = new JTextField(15);
		labelSexo = new JLabel("Sexo: ");
		checkSexo = new JCheckBox();
		labelOBS = new JLabel("OBS: ");
		formattedTextFieldOBS = new JTextArea();
		buttonOk = new JButton("OK");
		// --> adiciona os componentes a janela
		add(labelNome);
		add(textFieldNome);
		add(labelRG);
		add(textFieldRG);
		add(labelCPF);
		add(textFieldCPF);
		add(labelTelefone);
		add(textFieldTelefone);
		add(labelSexo);
		add(checkSexo);
		add(labelOBS);
		add(formattedTextFieldOBS);
		add(buttonOk);
		// --> ajusta o tamanho, a posicao e a acao ao fechar
		pack();
		setLocationRelativeTo(null);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		// --> mostra a janela
		setVisible(true);

	}

	// --> metodo main
	public static void main(String[] args) {
		// muda o LookAndFeel para parecer com uma aplicacao nativa
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
			e.printStackTrace();
		}
		// --> cria um novo objeto do tipo Swing1
		// por causa da execucao multithreading da
		// API swing,isso deve ser feito dessa forma:
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new FormularioGridLayout();
			}
		});
	}
}
