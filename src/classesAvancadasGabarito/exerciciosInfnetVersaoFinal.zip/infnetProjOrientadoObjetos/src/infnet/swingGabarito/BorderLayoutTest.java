package infnet.swingGabarito;

import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class BorderLayoutTest extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4924440530921285155L;

	public BorderLayoutTest() {
		JButton botao1 = new JButton("Botão 1");
		JButton botao2 = new JButton("Botão 2");
		JButton botao3 = new JButton("Botão 3");
		JButton botao4 = new JButton("Botão 4");
		JButton botao5 = new JButton("Botão 5");
		JTextField jTextPane = new JTextField();

		// Como o padrao de um JFrame é o
		// BorderLayout, simplesmente adicionamos
		// os componentes na tela
		getContentPane().add(botao1, BorderLayout.NORTH);
		getContentPane().add(botao2, BorderLayout.CENTER);

		getContentPane().add(botao3, BorderLayout.WEST);
		getContentPane().add(botao4, BorderLayout.SOUTH);
		getContentPane().add(botao5, BorderLayout.EAST);
		getContentPane().add(jTextPane, BorderLayout.PAGE_START);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		pack();
		setVisible(true);
	}

	public static void main(String args[]) {
		new BorderLayoutTest();
	}
}