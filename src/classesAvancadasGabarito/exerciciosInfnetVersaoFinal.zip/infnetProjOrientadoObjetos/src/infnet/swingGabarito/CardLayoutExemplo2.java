package infnet.swingGabarito;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class CardLayoutExemplo2 extends JFrame implements ActionListener {
	private static final long serialVersionUID = -6819580159590321363L;

	public static void main(String[] args) {
		new CardLayoutExemplo2();
	}

	@SuppressWarnings("deprecation")
	public CardLayoutExemplo2() {
		JPanel p = new JPanel();
		JPanel p1 = new JPanel();
		JPanel p2 = new JPanel();
		JPanel p3 = new JPanel();
		JPanel p4 = new JPanel();
		setSize(400, 600);
		CardLayout cm = new CardLayout();
		p.setLayout(cm);
		JButton b = new JButton("Teste");
		JButton b1 = new JButton("Teste1");
		JButton b2 = new JButton("Teste2");
		JButton b3 = new JButton("Teste3");
		JButton b4 = new JButton("Teste4");
		b.addActionListener(this);
		p.add(b, b.getLabel());
		p1.add(b1, b1.getLabel());
		p2.add(b2, b2.getLabel());
		p3.add(b3, b3.getLabel());
		p4.add(b4, b4.getLabel());
		add(p, BorderLayout.CENTER);
		add(p1, BorderLayout.EAST);
		add(p2, BorderLayout.NORTH);
		add(p3, BorderLayout.SOUTH);
		add(p4, BorderLayout.WEST);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JOptionPane.showMessageDialog(this, "Clicou no botão");
	}
}
