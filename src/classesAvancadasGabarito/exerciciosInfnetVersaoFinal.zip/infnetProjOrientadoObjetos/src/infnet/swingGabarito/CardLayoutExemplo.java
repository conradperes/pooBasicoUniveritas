package infnet.swingGabarito;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class CardLayoutExemplo extends JFrame {

	private static final long serialVersionUID = 7448181164533404022L;
	Panel central = new Panel();
	CardLayout cl = new CardLayout();

	class FirstHandler implements ActionListener {
		public void actionPerformed(ActionEvent ae) {
			cl.first(central);
		}
	}

	class LastHandler implements ActionListener {
		public void actionPerformed(ActionEvent ae) {
			cl.last(central);
		}
	}

	class NextHandler implements ActionListener {
		public void actionPerformed(ActionEvent ae) {
			cl.next(central);
		}
	}

	class PreviousHandler implements ActionListener {
		public void actionPerformed(ActionEvent ae) {
			cl.previous(central);
		}
	}

	public CardLayoutExemplo() {
		setTitle("Infnet - Exemplo CardLayout");
		setSize(240, 200);
		JButton next = new JButton("Proximo");
		next.addActionListener(new NextHandler());
		JButton previous = new JButton("Anterior");
		previous.addActionListener(new PreviousHandler());
		JButton first = new JButton("Primeiro");
		first.addActionListener(new FirstHandler());
		JButton last = new JButton("Ultimo");
		last.addActionListener(new LastHandler());
		add(first, BorderLayout.NORTH);
		add(last, BorderLayout.SOUTH);
		add(previous, BorderLayout.WEST);
		add(next, BorderLayout.EAST);
		add(central, BorderLayout.CENTER);
		central.setLayout(cl);
		central.add(new Label("Primeiro painel"), "Primeiro");
		central.add(new Label("Segundo painel"), "Segundo");
		central.add(new Label("Terceiro painel"), "Terceiro");
		central.add(new Label("Quarto painel"), "Quarto");
		central.add(new Label("Quinto painel"), "Quinto");
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}

	public static void main(String[] args) {
		CardLayoutExemplo jc = new CardLayoutExemplo();
		jc.setVisible(true);
	}

}
