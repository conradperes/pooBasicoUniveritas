package infnet.swingGabarito;

import java.awt.BorderLayout;

import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayer;
import javax.swing.JPanel;
import javax.swing.plaf.LayerUI;

public class JanelaUsandoLayer {
	JPanel panel;

	public JanelaUsandoLayer() {

	}

	public static void main(String[] args) {

		JanelaUsandoLayer janela = new JanelaUsandoLayer();
		janela.criarJanela();

	}

	private void criarJanela() {
		JFrame janela = new JFrame("Layer Exemplo");
		panel = criarPainel();
		LayerUI<JComponent> layerUI = new CamadaPapelParedeUI();
		JLayer<JComponent> jLayer = new JLayer<JComponent>(panel, layerUI);
		janela.add(jLayer);
		janela.getContentPane().add(panel, BorderLayout.LINE_END);
		janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		janela.pack();
		janela.setVisible(true);
	}

	private JPanel criarPainel() {
		panel = new JPanel();
		JComboBox<String> comboAlunosPos = new JComboBox<String>();
		for (int i = 0; i < 1000; i++) {
			comboAlunosPos.addItem("Aluno" + i);
		}
		JLabel labelAlunosPos = new JLabel("Alunos de Pós-Graduação");
		panel.add(labelAlunosPos);
		panel.add(comboAlunosPos);
		return panel;
	}

}
