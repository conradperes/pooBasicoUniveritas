package infnet.swingGabarito;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class SwingTela1 extends JFrame{

	private static final long serialVersionUID = 5650839099999723238L;
	JPanel panel;  
    JLabel msg;  
      
    public SwingTela1()  
    {  
        super("Primeira tela em Java!");  
    }  
      
    public void criaJanela()  
    {         
        panel = new JPanel();  
        msg = new JLabel("Infnet.com.br");  
          
        panel.add(msg);  
          
        getContentPane().add(panel, BorderLayout.CENTER);  
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
          
        pack();  
        setVisible(true);  
    }  
	public static void main(String[] args) {
		SwingTela1 tela1 = new SwingTela1();
		tela1.criaJanela();

	}

}
