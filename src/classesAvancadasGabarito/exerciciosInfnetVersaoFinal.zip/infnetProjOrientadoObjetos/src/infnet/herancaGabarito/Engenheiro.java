package infnet.herancaGabarito;

import java.util.Date;

public class Engenheiro extends Empregado {
	public Double calculoQuantico;

	public Engenheiro(String nome, Double salario, Date dataAniversario) {
		super(nome, salario, dataAniversario);
		getSecreto();
		
	}

}
