package infnet.herancaGabarito;

public class Macaco extends Animal {
	
	public void comer() {
		for(int i=0;i<10;i++)
			System.out.println("Macaco comendo banana!");
	}

}
