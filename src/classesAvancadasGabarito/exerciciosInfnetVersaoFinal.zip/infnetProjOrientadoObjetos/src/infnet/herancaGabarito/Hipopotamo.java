package infnet.herancaGabarito;

public class Hipopotamo extends Animal {
	public int tamanhoDentes;
	
	public Hipopotamo(int tamanhoDentes, int peso){
		this.tamanhoDentes=tamanhoDentes;
		setPeso(peso);
	}
	
	public void comer(){
		System.out.println("come plantas");
	}
}
