package infnet.herancaGabarito;

public class Poupanca extends Conta {
	public void reajuste(float juros){
		saldo*=juros;
	}

}
