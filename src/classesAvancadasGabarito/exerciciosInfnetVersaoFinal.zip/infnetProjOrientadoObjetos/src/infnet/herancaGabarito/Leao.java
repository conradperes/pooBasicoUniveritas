package infnet.herancaGabarito;

public class Leao extends Animal {
	
	public void comer(){
		super.comer();
		System.out.println("Cervo caçado hora do almoço!!!");
	}

}
