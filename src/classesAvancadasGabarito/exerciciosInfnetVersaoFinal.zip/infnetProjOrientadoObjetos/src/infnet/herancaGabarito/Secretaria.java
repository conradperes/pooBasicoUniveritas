package infnet.herancaGabarito;

import java.util.Date;

public class Secretaria extends Empregado {

	public Secretaria(String nome, Double salario, Date dataAniversario) {
		super(nome, salario, dataAniversario);
	}

	public Secretaria() {
		// TODO Auto-generated constructor stub
	}

}
