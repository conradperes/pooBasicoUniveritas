package infnet.herancaGabarito;

public class Conta {

	public Conta() {
	}

	protected float saldo;

	protected void saque(float s) {
		saldo -= s;
	}

}
